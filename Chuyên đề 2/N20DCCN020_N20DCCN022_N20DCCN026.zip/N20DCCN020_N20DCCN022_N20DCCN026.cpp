//VU HUY HUNG - N20DCCNN020
//VO QUANG HUY - N20DCCN022
//VAN TO HUU - N20DCCN026

#include <iostream>
#include <fstream>
#include <vector>
#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <queue>
#include <stack>
#include <algorithm>
#include<stdlib.h>
#include <cstring>
using namespace std;

int n, m, dau, dich;
vector<int> a[1000];
bool visited[1000];
int pre[1000];

void input(ifstream &in) {
    in >> n >> m >> dau >> dich;
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x;
        in >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    in.close();
    memset(visited, false, sizeof(visited));
    memset(pre, 0, sizeof(pre));
}

void bfs1(int u) {
    queue<int> q;
    q.push(u);
    visited[u] = true;
    while(!q.empty()) {
        int v = q.front();
        q.pop();
        for(int i : a[v]) {
            if (!visited[i]){
                q.push(i);
                visited[i] = true;
                pre[i] = v;
            }
        }
    }
}

void dfs1(int u) {
    visited[u] = true;
    for(int i : a[u]) {
        if (!visited[i]) {
            pre[i] = u;
            dfs1(i);
        }
    }
    
}

void BFS() {
    ifstream in;
    in.open("input.txt", ios_base::in);
    ofstream out;
    out.open("ouput.txt", ios_base::out);
    input(in);
    bfs1(dau);
    if (visited[dich]) {
        vector<int> res;
        while(dau != dich) {
            res.push_back(dich);
            dich = pre[dich];
        }
        res.push_back(dau);
        reverse(res.begin(), res.end());
        for (int i : res) {
            cout << i << " ";
            out << i << " ";
        }
    }
    else {
        cout << "khong tim thay!";
        out << "khong tim thay!";
    }
}

void DFS() {
    ifstream in;
    in.open("input.txt", ios_base::in);
    ofstream out;
    out.open("ouput.txt", ios_base::out);
    input(in);
    dfs1(dau);
    if (visited[dich]) {
        vector<int> res;
        while(dau != dich) {
            res.push_back(dich);
            dich = pre[dich];
        }
        res.push_back(dau);
        reverse(res.begin(), res.end());
        for (int i : res) {
            cout << i << " ";
            out << i << " ";
        }
    }
    else {
        cout << "khong tim thay!";
        out << "khong tim thay!";
    }
}

struct pQ
{
    list<int> path;
    int cost;
    bool operator>(const pQ& rhs) const
    {
        return cost > rhs.cost;
    }
};

class mycomparison
{
public:
    bool operator() (pQ p1, pQ p2) const
    {
        return (p1>p2);
    }
};

class Graph
{
    int V;
    vector<int> *adj;
    vector<int> *wgt;
public:
    Graph(int V);
    void addEdge(int v, int w, int wgt);
    void UCF(int s, int t);
    void displayPath(struct pQ f);
};

Graph::Graph(int V)
{
    this->V = V;
    adj = new vector<int>[V];
    wgt = new vector<int>[V];
}

void Graph::addEdge(int v, int w, int wt) {
    adj[v].push_back(w);
    wgt[v].push_back(wt);
}
void Graph::UCF(int s, int t)
{
    int current=0, pos=0;
    typedef priority_queue<pQ,vector<pQ>,mycomparison> mypq_type;
    mypq_type pq;

    pQ vstart;

    vstart.path.push_back(s);
    vstart.cost = 0;

    vector<int>::iterator i;
    pq.push(vstart);

    while(!pq.empty())
    {
        pQ currentPQ, tempPQ;
        current = pq.top().path.back();
        currentPQ = pq.top();
        pq.pop();
        if(current == t)
        {
            displayPath(currentPQ);
            exit(0);
        }
        else{
            for (i = adj[current].begin(); i != adj[current].end(); ++i)
            {
                tempPQ = currentPQ;
                tempPQ.path.push_back(*i);
                pos = find(adj[current].begin(), adj[current].end(), *i) - adj[current].begin();
                tempPQ.cost += wgt[current].at(pos);
                pq.push(tempPQ);
            }
        }
    }
}

void Graph::displayPath(struct pQ p)
{
  ofstream out;
  out.open("UCSOUt.txt", ios_base::out);
  list<int>::iterator i;
  out<<"Duong di: ";
  for (i = p.path.begin(); i != p.path.end(); ++i)
  {
    if(i!=p.path.begin())
    out<<"->";
    out<<*i;
  }
  out<<endl;
  out<<"Chi phi: "<<p.cost;
  out.close();
}


void UCF()
{
    int n, a, b, c;
    int vstart = 0, vend = 0;
    ifstream input("UCSIn.txt");
    input >> n;
    Graph g(n);
    input >> vstart;
    input >> vend;
    while(!input.eof())
    {

        input >> a >> b >> c;
        g.addEdge(a, b, c);
    }
    g.UCF(vstart, vend);
}


void DLS()
{
    ifstream in;
    in.open("DLSIn.txt", ios_base::in);
    ofstream out;
    out.open("DLSOut.txt", ios_base::out);
    int v, e, limit, s, t, v1, v2, current = 0;
    bool a[1000][1000];
    in >> v >> e >> s >> t >> limit;
    bool checked[v];
    int trace[v];
    int level[v];
    memset(checked, false, sizeof(checked));
    memset(trace, 0, sizeof(trace));
    memset(level, 0, sizeof(level));
    stack<int> stack;
    for (int i = 0; i < e; i++)
    {
        in >> v1 >> v2;
        a[v1][v2] = 1;
        a[v2][v1] = 1;
    }
    stack.push(s);
    level[s] = 1;
    bool isTaget = false;
    while (!stack.empty())
    {
        current = stack.top();
        stack.pop();
        checked[current] = true;
        if (current == t) {
            isTaget = true;
            break;
        }
        if (level[current] <= limit)
        {
            for (int i = v; i >=1; i--)
             {
                if (!checked[i] && a[current][i])
                {
                    stack.push(i);
                    trace[i] = current;
                    level[i] = level[current] + 1;
                }
            }
        }
    }
    if (isTaget)
    {
        int u = t;
        while (trace[u] != 0)
        {
            out << u << "->";
            u = trace[u];
        }
        out << s;
    }
    else
    {
        out << "Khong tim thay" << endl;
    }
    in.close();
    out.close();
}

void IDS()
{
	ifstream in;
    in.open("IDSIn.txt", ios_base::in);
    ofstream out;
    out.open("IDSOut.txt", ios_base::out);
    int v, e, limit, s, t, v1, v2, current = 0, step;
    bool a[1000][1000];
    in >> v >> e >> s >> t >> limit >> step;
    bool checked[v];
    int trace[v];
    int level[v];
    memset(checked, false, sizeof(checked));
    memset(trace, 0, sizeof(trace));
    memset(level, 0, sizeof(level));
    deque<int> deque;
    for (int i = 0; i < e; i++)
    {
    	in >> v1 >> v2;
    	a[v1][v2] = 1;
    	a[v2][v1] = 1;
	}
	deque.push_back(s);
	level[s] = 0;
	bool isTaget = false;
	while (!deque.empty())
	{
		current = deque.back();
		deque.pop_back();
		checked[current] = true;
		if (current == t) {
			isTaget = true;
			break;
		}
		cout << current << " " << level[current] << endl;
		if (level[current] < limit)
		{
	    	for (int i = v; i >=1; i--)
	 	    {
			    if (!checked[i] && a[current][i])
				{ 
				//cout << i << endl;
					deque.push_back(i);		
					trace[i] = current;
					level[i] = level[current] + 1;
				}
			}	
		}
		else
			if (level[current] == limit)
			{
				for (int i = v; i >=1; i--)
	 	    	{
			    	if (!checked[i] && a[current][i])
					{
						deque.push_front(i);		
						trace[i] = current;
						level[i] = level[current] + 1;
					}
				}	
			}
		else
		{
			limit += step;
			if (step == 1)
			{
				for (int i = v; i >=1; i--)
	 	    	{
			    	if (!checked[i] && a[current][i])
					{
						deque.push_front(i);		
						trace[i] = current;
						level[i] = level[current] + 1;
					}
				}
			} else
			{
				for (int i = v; i >=1; i--)
	 	       {
			        if (!checked[i] && a[current][i])
					{
						deque.push_back(i);		
						trace[i] = current;
						level[i] = level[current] + 1;
					}
			}
			}
		}
	}
	if (isTaget)
	{
		int u = t;
		while (trace[u] != 0)
		{
			out << u << "->";
			u = trace[u];
		}
		out << s;
	}
	else
	{
		out << "Khong tim thay" << endl;
	}
	in.close();
	out.close();
}



int main()
{
    BFS();
    DFS();
    DLS();
    UCF();
    IDS();
    return 0;
}
